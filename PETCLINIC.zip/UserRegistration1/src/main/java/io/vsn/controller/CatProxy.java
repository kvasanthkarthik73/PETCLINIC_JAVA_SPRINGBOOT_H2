package io.vsn.controller;

public interface CatProxy {
    void sleep();
    void eat();
    void play();
}
