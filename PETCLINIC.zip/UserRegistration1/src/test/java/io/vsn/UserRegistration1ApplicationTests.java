package io.vsn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRegistration1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
