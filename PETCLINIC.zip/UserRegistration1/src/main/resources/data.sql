insert into User (user_id,user_fname,user_lname,user_email,user_pass,user_mobile) values (1,'Aadeesh','Jain','aadeeshjain.91a@yahoo.com','abcd@234','9876543212');
insert into User (user_id,user_fname,user_lname,user_email,user_pass,user_mobile) values (2,'Andrew','Jate','andrewjate.df@yahoo.com','andrew@9','9876547542');
insert into User (user_id,user_fname,user_lname,user_email,user_pass,user_mobile) values (3,'John','Deed','john619.91a@yahoo.com','john@3113','9876544444');
insert into User (user_id,user_fname,user_lname,user_email,user_pass,user_mobile) values (4,'Peter','Parker','peter.parker@gmail.com','pet_er@9','9871117542');
