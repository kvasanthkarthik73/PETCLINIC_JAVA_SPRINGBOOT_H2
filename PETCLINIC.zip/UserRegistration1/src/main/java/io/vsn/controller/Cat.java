package io.vsn.controller;
public class Cat {
    public void sleep() {
        // Code for sleeping
        System.out.println("The cat will sleep at 9 p.m everyday.");
    }

    public void eat() {
        // Code for eating
        System.out.println("The cat is eating its food.");
    }

    public void play() {
        // Code for playing
        System.out.println("The cat is playing with a toy mouse.");
    }
}
